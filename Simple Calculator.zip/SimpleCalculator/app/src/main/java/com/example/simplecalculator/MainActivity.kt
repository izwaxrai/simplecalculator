package com.example.simplecalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var number1: EditText
    private lateinit var number2: EditText
    private lateinit var buttonAdd: Button
    private lateinit var buttonMinus: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var textviewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Link UI elements
        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        buttonAdd = findViewById(R.id.btn_add)
        buttonMinus = findViewById(R.id.btn_minus)
        buttonMultiply = findViewById(R.id.btn_multiply)
        buttonDivide = findViewById(R.id.btn_divide)
        textviewResult = findViewById(R.id.answer)

        // Set click listeners for all four operations
        buttonAdd.setOnClickListener { calculate('+') }
        buttonMinus.setOnClickListener { calculate('-') }
        buttonMultiply.setOnClickListener { calculate('*') }
        buttonDivide.setOnClickListener { calculate('/') }
    }

    private fun calculate(operator: Char) {
        val num1 = number1.text.toString().toDoubleOrNull()
        val num2 = number2.text.toString().toDoubleOrNull()

        if (num1 == null || num2 == null) {
            Toast.makeText(this, "Please enter valid numbers in both fields", Toast.LENGTH_SHORT).show()
            textviewResult.text = "Please enter numbers"
            return
        }

        // Handle division by zero
        if (operator == '/' && num2 == 0.0) {
            Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
            textviewResult.text = "Error: Div by 0"
            return
        }

        val result = when (operator) {
            '+' -> num1 + num2
            '-' -> num1 - num2
            '*' -> num1 * num2
            '/' -> num1 / num2
            else -> 0.0
        }

        // Format result: display as integer if there's no fractional part
        textviewResult.text = if (result % 1 == 0.0) {
            result.toLong().toString()
        } else {
            result.toString()
        }
    }
}